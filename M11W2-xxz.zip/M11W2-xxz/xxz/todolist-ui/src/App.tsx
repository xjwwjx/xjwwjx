import { Button, Container, createTheme, CssBaseline, Dialog, DialogTitle, Fab, IconButton, List, ListItem, ListItemText, Radio, TextField, Theme, ThemeProvider, ListItemAvatar, ToggleButtonGroup, ToggleButton, DialogActions, DialogContent } from '@mui/material';
import React, { useEffect, useState } from 'react';
import { createStyles, makeStyles } from '@mui/styles'
import AddIcon from '@mui/icons-material/Add';
import ClearIcon from '@mui/icons-material/Clear';
import PushPinIcon from '@mui/icons-material/PushPin';

const theme = createTheme({
  palette: {
    mode: 'dark',
  },
});

interface Todo {
  id: number,
  text: string,
  date_added: string,
  pinned: boolean,
  finished: boolean,
}

const useStyles = makeStyles((theme: Theme) => createStyles({
  container: {
    textAlign: 'center',
    marginTop: 50
  },
  pinned: {
    transform: 'rotate(45deg)'
  },
  dialog: {
    margin: 20
  }
}))

const App = () => {
  const [todosPinned, setTodosPinned] = useState([] as Todo[])
  const [todosNormal, setTodosNormal] = useState([] as Todo[])
  const [todosFinished, setTodosFinished] = useState([] as Todo[])

  const [renderList, setRenderedList] = useState('all')

  const [changed, setChanged] = useState(0)
  useEffect(
    () => {
      (async () => {
        const r: Todo[] = await (await fetch(`/api/get`)).json()
        console.log(r)

        let todosFinished = []
        let todosPinned = []
        let todosNormal = []
        for (const t of r) {
          if (t.finished) {
            todosFinished.push(t)
          } else {
            if (t.pinned) {
              todosPinned.push(t)
            } else {
              todosNormal.push(t)
            }
          }
        }

        setTodosPinned(todosPinned)
        setTodosNormal(todosNormal)
        setTodosFinished(todosFinished)
      })()
    },
    [changed]
  )


  const classes = useStyles()

  const [open, setOpen] = useState(false)

  const handleClickOpen = () => {
    setOpen(true)
  }

  const handleClose = () => {
    setOpen(false)
  }

  const [text, setText] = useState('???')

  const handleAdd = async () => {
    await fetch(`/api/add`, {
      body: text,
      method: 'POST'
    })
    setChanged(changed + 1)
    setOpen(false)
  }

  const todoItem = (todo: Todo) => <ListItem key={todo.id} secondaryAction={
    <div>{todo.finished ? null : <IconButton edge="end" aria-label="pin" onClick={
      async () => {
        todo.pinned = !todo.pinned
        await fetch(`/api/update?id=${todo.id}`, {
          method: 'POST',
          body: JSON.stringify(todo)
        })
        setChanged(changed + 1)
      }
    }>
      {todo.pinned ? <PushPinIcon className={classes.pinned} /> : <PushPinIcon />}
    </IconButton>}
      <IconButton edge="end" aria-label="delete" onClick={
        async () => {
          await fetch(`/api/delete?id=${todo.id}`, {
            method: 'DELETE'
          })
          setChanged(changed + 1)
        }
      }>
        <ClearIcon />
      </IconButton>
    </div>
  }>
    <ListItemAvatar><Radio checked={todo.finished} onClick={async () => {
      todo.finished = !todo.finished
      await fetch(`/api/update`, {
        method: 'POST',
        body: JSON.stringify(todo)
      })
      setChanged(changed + 1)
    }} /></ListItemAvatar>
    <ListItemText primary={todo.text} secondary={(new Date(todo.date_added).toLocaleString('zh-CN'))} />
  </ ListItem>

  const rendered = (() => {
    if (renderList === 'all') {
      return todosPinned.map(todoItem).concat(
        todosNormal.map(todoItem)).concat(
          todosFinished.map(todoItem)
        )
    } else if (renderList === 'finished') {
      return todosFinished.map(todoItem)
    } else {
      return todosPinned.map(todoItem).concat(
        todosNormal.map(todoItem))
    }
  })()

  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <Container maxWidth="sm" className={classes.container}>
        <ToggleButtonGroup exclusive onChange={(_, r) => {
          setRenderedList(r)
        }} >
          <ToggleButton value="all" key="all">All</ToggleButton>
          <ToggleButton value="unfinished" key="unfinished">Unfinished</ToggleButton>
          <ToggleButton value="finished" key="finished">Finished</ToggleButton>
        </ToggleButtonGroup>
        <Dialog onClose={handleClose} open={open}>
          <DialogTitle>Add TODO</DialogTitle>
          <DialogContent>
            <TextField className={classes.dialog} variant="standard" onChange={(v) => setText(v.target.value)} />
          </DialogContent>
          <DialogActions><Button type="submit" onClick={handleAdd}>ADD</Button></DialogActions>
        </Dialog>
        <List>
          {
            rendered
          }
        </List>
        <Fab color="primary" onClick={handleClickOpen}><AddIcon /> </Fab>
      </Container>
    </ThemeProvider>
  )
}

export default App;
