#![feature(map_first_last)]
use std::{
    collections::{btree_map::Entry, BTreeMap},
    sync::{atomic::AtomicU32, RwLock},
};

use chrono::{DateTime, Utc};
use rocket::{serde::json::Json, State};
use serde::{Deserialize, Serialize};
use std::sync::atomic::Ordering::SeqCst;

#[macro_use]
extern crate rocket;

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct Todo {
    pub id: u32,
    pub text: String,
    pub date_added: DateTime<Utc>,
    pub pinned: bool,
    pub finished: bool,
}

static ID_GENERATOR: AtomicU32 = AtomicU32::new(0);

#[post("/add", data = "<text>")]
fn add(text: String, db: &State<RwLock<BTreeMap<u32, Todo>>>) -> Json<Todo> {
    let id = ID_GENERATOR.fetch_add(1, SeqCst);
    let todo = Todo {
        id,
        text,
        date_added: Utc::now(),
        finished: false,
        pinned: false,
    };
    db.write().unwrap().insert(id, todo.clone());
    Json(todo)
}

#[post("/update", data = "<todo>")]
fn update(todo: Json<Todo>, db: &State<RwLock<BTreeMap<u32, Todo>>>) -> Option<()> {
    if let Entry::Occupied(mut t) = db.write().unwrap().entry(todo.id) {
        t.insert(todo.0);
        Some(())
    } else {
        None
    }
}

#[delete("/delete?<id>")]
fn delete(id: u32, db: &State<RwLock<BTreeMap<u32, Todo>>>) -> Option<()> {
    if let Entry::Occupied(t) = db.write().unwrap().entry(id) {
        t.remove();
        Some(())
    } else {
        None
    }
}

#[get("/get")]
fn get(db: &State<RwLock<BTreeMap<u32, Todo>>>) -> Json<Vec<Todo>> {
    Json(db.read().unwrap().values().cloned().collect())
}

#[launch]
fn rocket() -> _ {
    let db: RwLock<BTreeMap<u32, Todo>> = RwLock::new({
        let mut map = BTreeMap::new();
        map.insert(
            0,
            Todo {
                date_added: Utc::now(),
                finished: false,
                id: 0,
                pinned: false,
                text: "test".to_string(),
            },
        );
        map.insert(
            1,
            Todo {
                date_added: Utc::now(),
                finished: false,
                id: 1,
                pinned: true,
                text: "test2".to_string(),
            },
        );
        map.insert(
            2,
            Todo {
                date_added: Utc::now(),
                finished: true,
                id: 2,
                pinned: false,
                text: "test3".to_string(),
            },
        );
        map
    });
    if let Some((id, _)) = db.read().unwrap().last_key_value() {
        ID_GENERATOR.store(*id + 1, SeqCst)
    }
    rocket::build()
        .manage(db)
        .mount("/api", routes![add, update, delete, get])
}
